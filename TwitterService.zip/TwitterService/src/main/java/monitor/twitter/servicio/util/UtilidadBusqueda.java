package monitor.twitter.servicio.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import twitter4j.*;
import twitter4j.auth.AccessToken;

@Component
public class UtilidadBusqueda {

	private Twitter twitter;

	public UtilidadBusqueda() {
		twitter = new TwitterFactory().getInstance();
		twitter.setOAuthConsumer("ta15koylQHfUC4ojEguhPA", "ZOxYrDm3Bx7vppUQYoRMftvStx8wGEk72YP0bfnBs");
		AccessToken accessToken = new AccessToken("29106709-UT4oXNiWug8eciawIyEfNBmwRB3rt73VqhplC8KlV",
				"RfKv8LsZaIx68uGYUdy0gZfTluWYcAjxc33DEi53gClvE");
		twitter.setOAuthAccessToken(accessToken);
	}

	public List<Map<String, Object>> buscarTuits(String concepto) {
		List<Map<String, Object>> listaTuits = new ArrayList();
		Query query = new Query(concepto);
		query.setGeoCode(new GeoLocation(4.5981, -74.0758), 10, Query.KILOMETERS);
		query.setCount(100);

		try {
			Map<String, Object> mapa = new HashMap<String, Object>();

			int i = 0;
			QueryResult result = null;
			result = twitter.search(query);
			do {
				try {
					
					for (Status status : result.getTweets()) {

						mapa = new HashMap<String, Object>();
						mapa.put("nombreUsuario", status.getUser().getScreenName());
						mapa.put("fecha", status.getCreatedAt());
						if (status.getPlace() != null) {
							Map<String, Object> mapaUbicacion = new HashMap<String, Object>();
							mapaUbicacion.put("pais", status.getPlace().getCountry());
							mapaUbicacion.put("ciudad", status.getPlace().getFullName());
							mapaUbicacion.put("coord", status.getGeoLocation());
							mapa.put("ubicacion", mapaUbicacion);
						}
						mapa.put("text", status.getText());
						listaTuits.add(mapa);

					}
					query = result.nextQuery();

				} catch (Exception e) {
					// do what ever you want
				}
			} while ( result.hasNext() && listaTuits.size()<1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(listaTuits.size());

		return listaTuits;
	}

}
