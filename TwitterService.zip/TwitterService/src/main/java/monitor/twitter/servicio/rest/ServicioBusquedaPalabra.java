package monitor.twitter.servicio.rest;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import monitor.twitter.servicio.util.UtilidadBusqueda;

@RestController
@RequestMapping(value = "twitter/tuits", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class ServicioBusquedaPalabra {

	@Autowired
	private UtilidadBusqueda utilidadBusqueda;

	/**
	 * Endoint para busqueda twitter por conceptos
	 * 
	 * @return
	 */
	@RequestMapping(value = "/concepto/{concepto}", method = RequestMethod.GET)
	public List<Map<String, Object>> obtenerTuitsXConcepto(@PathVariable("concepto") String concepto) {
		return utilidadBusqueda.buscarTuits(concepto);
	}

}
